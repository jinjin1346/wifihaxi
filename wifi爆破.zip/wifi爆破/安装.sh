#!/system/bin/sh
clear

# 颜色定义
R='\033[0;31m'
G='\033[0;32m'
Y='\033[1;33m'
B='\033[0;34m'
N='\033[0m'

echo -e "${B}===============================================${N}"
echo -e "${G}   WiFi 爆破工具 一键安装程序${N}"
echo -e "${B}===============================================${N}"

# 1. 获取当前目录
CUR_DIR=$(pwd)
echo -e "${G}✅ 当前目录: ${Y}$CUR_DIR${N}"

# 2. 检测库文件夹和主程序
LIB_DIR="$CUR_DIR/lib"
BIN_FILE="$LIB_DIR/aircrack-ng"
CFG_FILE="$CUR_DIR/wifi_config.conf"

if [ ! -d "$LIB_DIR" ]; then
    echo -e "${R}❌ 错误：未找到 lib 库文件夹！${N}"
    echo -e "${Y}请确保 lib 文件夹和 install.sh 在同一目录下。${N}"
    exit 1
fi

if [ ! -f "$BIN_FILE" ]; then
    echo -e "${R}❌ 错误：未找到主程序 aircrack-ng！${N}"
    echo -e "${Y}请确保主程序在 lib 文件夹内。${N}"
    exit 1
fi

echo -e "${G}✅ 检测到库文件夹: ${Y}$LIB_DIR${N}"
echo -e "${G}✅ 检测到主程序: ${Y}$BIN_FILE${N}"

# 3. 赋权所有文件
echo -e "${Y}正在给所有文件赋权 777...${N}"
chmod -R 777 "$CUR_DIR"
echo -e "${G}✅ 赋权完成${N}"

# 4. 写入默认配置
echo -e "${Y}正在生成配置文件...${N}"
cat > "$CFG_FILE" << EOF
THREAD=8
BIN="$BIN_FILE"
LIBPATH="$LIB_DIR"
DEFDICT="/storage/emulated/0/WiFi/3.txt"
EOF

echo -e "${G}✅ 配置文件生成完成: ${Y}$CFG_FILE${N}"
echo -e "${G}✅ 线程数: 8${N}"
echo -e "${G}✅ 工具路径: $BIN_FILE${N}"
echo -e "${G}✅ 库路径: $LIB_DIR${N}"
echo -e "${G}✅ 默认字典: /storage/emulated/0/WiFi/3.txt${N}"

echo -e "${B}===============================================${N}"
echo -e "${G}🎉 安装完成！${N}"
echo -e "${Y}配置文件已自动生成，路径已写入。${N}"
echo -e "${B}===============================================${N}"
